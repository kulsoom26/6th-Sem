import * as React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import boots from './assets/boots.jpg';
import cake from './assets/cake.jpg';
import hoodie from './assets/hoodie.jpg';
import waffle from './assets/waffle.jpg';

const ProList = [
  {url:boots, price:'4599 Rs', name: 'Combat Boots', qty:19},
  {url:cake, price:'999 Rs', name: 'Chocolate Cake', qty:20},
  {url:hoodie, price:'1499 Rs', name: 'Hoodie', qty:50},
  {url:waffle, price:'12799 Rs', name: 'Waffle Maker', qty:12}
];
const OrdList = [
  {ordNo: 1, prodName: 'Hoodie', price: '1499 Rs', status: 'out for delivery', customerName: 'Aaiza Irfaan', customerContact: '0334-8976554', customerCNIC:'41404-876554-3', ordDate:'23-11-2022'},
  {ordNo: 2, prodName: 'Cake', price: '999 Rs', status: 'Delivered', customerName: 'Hammad Tufail', customerContact: '0334-8432254', customerCNIC:'41404-87655423-3', ordDate:'2-10-2022'},
  {ordNo: 3, prodName: 'Combat boots', price: '4599 Rs', status: 'out for delivery', customerName: 'Ayesha Iftikhar', customerContact: '0334-8987664', customerCNIC:'41404-87655421-3', ordDate:'11-11-2022'},
  {ordNo: 4, prodName: 'Waffle Maker', price: '12999 Rs', status: 'out for delivery', customerName: 'Wasif Farid', customerContact: '0332-5316694', customerCNIC:'41404-8929558-3', ordDate:'12-1-2021'}
];
const EmployeeList = [
  {name:'Kulsoom Khurshid', designation: 'Accountant', age: 21, salary: 30000},
  {name:'Labeeka Hameed', designation: 'Manager', age: 30, salary: 70000},
  {name:'Ali Affan', designation: 'Cashier', age: 19, salary: 15000}
];

function HomeScreen({navigation}) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>

      <TouchableOpacity 
      style={styles.homeButton} 
      onPress={()=> navigation.navigate("Products List")}>
        <Text style={styles.homeText}>Manage Products</Text>
      </TouchableOpacity>

      <TouchableOpacity 
      style={styles.homeButton1} 
      onPress={()=> navigation.navigate("Employees List")}>
        <Text style={styles.homeText}>Manage Employees</Text>
      </TouchableOpacity>
      
      <TouchableOpacity 
      style={styles.homeButton1} 
      onPress={()=> navigation.navigate("Orders List")}>
        <Text style={styles.homeText}>Manage Orders</Text>
      </TouchableOpacity>

    </View>
  );
}
function ProductsList({navigation}) {
  return (
    <View style={{ flex: 1, textAlign:'center', backgroundColor:'#ffe4e1'}}>

      <Text style={styles.productListHeading}>Products</Text>

      <TouchableOpacity
      style={styles.productListButtons}
      onPress={()=> navigation.navigate("Product Details",{id:0})}>
        <Image style={{width:100, height:100, alignSelf:'center', marginBottom:10, marginTop:10}} source= {boots}/>
        <Text style={styles.productButtonText}>Name: {ProList[0].name}</Text>
        <Text style={styles.productButtonText}>Price: {ProList[0].price}</Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.productListButtons}
      onPress={()=> navigation.navigate("Product Details",{id:1})}>
        <Image style={{width:100, height:100, alignSelf:'center', marginBottom:10, marginTop:10}} source= {cake}/>
        <Text style={styles.productButtonText}>Name: {ProList[1].name}</Text>
        <Text style={styles.productButtonText}>Price: {ProList[1].price}</Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.productListButtons}
      onPress={()=> navigation.navigate("Product Details",{id:2})}>
        <Image style={{width:100, height:100, alignSelf:'center', marginBottom:10, marginTop:10}} source= {hoodie}/>
        <Text style={styles.productButtonText}>Name: {ProList[2].name}</Text>
        <Text style={styles.productButtonText}>Price: {ProList[2].price}</Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.productListButtons}
      onPress={()=> navigation.navigate("Product Details",{id:3})}>
        <Image style={{width:100, height:100, alignSelf:'center', marginBottom:10, marginTop:10}} source= {waffle}/>
        <Text style={styles.productButtonText}>Name: {ProList[3].name}</Text>
        <Text style={styles.productButtonText}>Price: {ProList[3].price}</Text>
      </TouchableOpacity>
    </View>
  );
}
function ProductDetails({route}) {
  return (
    <View style={{ flex: 1, textAlign:'center', backgroundColor:'#ffe4e1'}}>

      <Text style={styles.productDetailHeading}>Product Detail</Text>
      <View style={styles.prodDetailBox}>
        <Image style={{width:200,height:200, marginTop:10, alignSelf:'center', marginBottom:20}} source= {ProList[route.params.id].url}/>
        <Text 
        style={styles.productDetailText}>
        Name: {ProList[route.params.id].name}</Text>
        <Text 
        style={styles.productDetailText}>
        Price: {ProList[route.params.id].price}</Text>
        <Text 
        style={styles.employeeDetailText}>
        Quantity: {ProList[route.params.id].qty}</Text>
      </View>
    </View>
  );
}
function EmployeesList({navigation}) {
  return (
    <View style={{ flex: 1, textAlign:'center',backgroundColor:'#d8bfd8'}}>

      <Text style={styles.employeeListHeading}>Employees</Text>

      <TouchableOpacity
      style={styles.employeeListButtons}
      onPress={()=> navigation.navigate("Employee Detail",{id:0})}>
        <Text style={styles.employeeButtonText}>Name: {EmployeeList[0].name}</Text>
        <Text style={styles.employeeButtonText}>Designation: {EmployeeList[0].designation}</Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.employeeListButtons}
      onPress={()=> navigation.navigate("Employee Detail",{id:1})}>
        <Text style={styles.employeeButtonText}>Name: {EmployeeList[1].name}</Text>
        <Text style={styles.employeeButtonText}>Designation: {EmployeeList[1].designation}</Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.employeeListButtons}
      onPress={()=> navigation.navigate("Employee Detail",{id:2})}>
        <Text style={styles.employeeButtonText}>Name: {EmployeeList[2].name}</Text>
        <Text style={styles.employeeButtonText}>Designation: {EmployeeList[2].designation}</Text>
      </TouchableOpacity>
    </View>
  );
}
function EmployeeDetails({route}) {
  return (
    <View style={{ flex: 1, textAlign:'center', backgroundColor:'#d8bfd8'}}>

      <Text style={styles.employeeDetailHeading}>Employee Detail</Text>
      <View style={styles.empDetailBox}>
        <Text 
        style={styles.employeeDetailText}>
        Name: {EmployeeList[route.params.id].name}</Text>
        <Text 
        style={styles.employeeDetailText}>
        Designation: {EmployeeList[route.params.id].designation}</Text>
        <Text 
        style={styles.employeeDetailText}>
        Age: {EmployeeList[route.params.id].age}</Text>
        <Text 
        style={styles.employeeDetailText}>
        Salary: {EmployeeList[route.params.id].salary}</Text>
      </View>
    </View>
  );
}
function OrdersList({navigation}) {
  return (
    <View style={{ flex: 1, textAlign:'center', backgroundColor:'#ff9994'}}>

      <Text style={styles.orderListHeading}>Orders</Text>

      <TouchableOpacity
      style={styles.orderListButtons}
      onPress={()=> navigation.navigate("Order Details",{id:0})}>
        <Text style={styles.orderButtonText}>Order Number: {OrdList[0].ordNo}</Text>
        <Text style={styles.orderButtonText}>Product Name: {OrdList[0].prodName}</Text>
        <Text style={styles.orderButtonText}>Price: {OrdList[0].price}</Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.orderListButtons}
      onPress={()=> navigation.navigate("Order Details",{id:1})}>
        <Text style={styles.orderButtonText}>Order Number: {OrdList[1].ordNo}</Text>
        <Text style={styles.orderButtonText}>Product Name: {OrdList[1].prodName}</Text>
        <Text style={styles.orderButtonText}>Price: {OrdList[1].price}</Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.orderListButtons}
      onPress={()=> navigation.navigate("Order Details",{id:2})}>
        <Text style={styles.orderButtonText}>Order Number: {OrdList[2].ordNo}</Text>
        <Text style={styles.orderButtonText}>Product Name: {OrdList[2].prodName}</Text>
        <Text style={styles.orderButtonText}>Price: {OrdList[2].price}</Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.orderListButtons}
      onPress={()=> navigation.navigate("Order Details",{id:3})}>
        <Text style={styles.orderButtonText}>Order Number: {OrdList[3].ordNo}</Text>
        <Text style={styles.orderButtonText}>Product Name: {OrdList[3].prodName}</Text>
        <Text style={styles.orderButtonText}>Price: {OrdList[3].price}</Text>
      </TouchableOpacity>
    </View>
  );
}
function OrderDetails({route}) {
  return (
    <View style={{ flex: 1, textAlign:'center', backgroundColor:'#ff9994'}}>

      <Text style={styles.orderDetailHeading}>Order Detail</Text>
      <View style={styles.ordDetailBox}>
        <Text 
        style={styles.orderDetailText}>
        Order No: {OrdList[route.params.id].ordNo}</Text>
        <Text 
        style={styles.orderDetailText}>
        Product: {OrdList[route.params.id].prodName}</Text>
        <Text 
        style={styles.orderDetailText}>
        Price: {OrdList[route.params.id].price}</Text>
        <Text 
        style={styles.orderDetailText}>
        Order Date: {OrdList[route.params.id].ordDate}</Text>
        <Text 
        style={styles.orderDetailText}>
        Customer Name: {OrdList[route.params.id].customerName}</Text>
        <Text 
        style={styles.orderDetailText}>
        Customer Contact: {OrdList[route.params.id].customerContact}</Text>
        <Text 
        style={styles.orderDetailText}>
        Customer CNIC: {OrdList[route.params.id].customerCNIC}</Text>
        <Text 
        style={styles.orderDetailText}>
        Delivery Status: {OrdList[route.params.id].status}</Text>
      </View>
    </View>
  );
}

const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Products List" component={ProductsList} />
        <Stack.Screen name="Product Details" component={ProductDetails} />
        <Stack.Screen name="Employees List" component={EmployeesList} />
        <Stack.Screen name="Employee Detail" component={EmployeeDetails} />
        <Stack.Screen name="Orders List" component={OrdersList} />
        <Stack.Screen name="Order Details" component={OrderDetails} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  homeButton:{
    backgroundColor:'#db7093', 
    width: 300,
    height: 50, 
    borderRadius:10
  },
  homeButton1:{
    backgroundColor:'#db7093', 
    width: 300,
    height: 50, 
    borderRadius:10,
    marginTop:20
  },
  homeText:{
    color:'white', 
    marginTop:10, 
    marginLeft:70, 
    fontWeight:'bold', 
    fontSize:20
  },
  employeeListHeading:{
    fontSize:30, 
    fontWeight:'bold',
    color:'purple',
  },
  employeeListButtons:{
    borderWidth:3, 
    width:200, 
    marginTop:20, 
    height:50, 
    alignSelf:'center', 
    borderColor:'purple',
    borderRadius: 8,
    backgroundColor:'purple'
  },
  employeeButtonText:{
    fontSize:16,
    color: 'white',
  },
  employeeDetailHeading:{
    fontSize:26, 
    fontWeight:'bold',
    color:'purple',
  },
  empDetailBox:{
    borderWidth:3,
    marginTop:20,
    width: 250,
    height:150,
    paddingLeft:10,
    paddingBottom:10,
    borderColor:'purple',
    alignSelf:'center'
  },
  employeeDetailText:{
    marginTop:7,
    fontSize:20,
    textAlign:'left'
  },
  orderListHeading:{
    fontSize:30, 
    fontWeight:'bold',
    color:'#D10000',
  },
  orderListButtons:{
    borderWidth:3, 
    width:250, 
    marginTop:20, 
    height:70, 
    alignSelf:'center', 
    borderColor:'#D10000',
    borderRadius:8,
    backgroundColor:'#D10000'
  },
  orderButtonText:{
    fontSize:16,
    color:'white'
  },
  orderDetailHeading:{
    fontSize:26, 
    fontWeight:'bold',
    color:'#D10000',
  },
  ordDetailBox:{
    borderWidth:3,
    marginTop:20,
    width: 300,
    height:250,
    borderColor:'#D10000',
    padding:10,
    alignSelf:'center'
  },
  orderDetailText:{
    marginTop:7,
    fontSize:16,
    textAlign:'left'
  },
  productListHeading:{
    fontSize:30, 
    fontWeight:'bold',
    color:'#c71585',
  },
  productListButtons:{
    borderWidth:3, 
    width:200, 
    marginTop:20, 
    height:180, 
    alignSelf:'center', 
    borderColor:'#c71585',
    borderRadius: 8,
    backgroundColor: '#c71585'
  },
  productButtonText:{
    fontSize:16,
    color: 'white',
  },
  productDetailHeading:{
    fontSize:26, 
    fontWeight:'bold',
    color:'#c71585',
  },
  prodDetailBox:{
    borderWidth:3,
    marginTop:20,
    width: 250,
    height:350,
    padding:10,
    borderColor:'#c71585',
    alignSelf:'center'
  },
  productDetailText:{
    marginTop:7,
    fontSize:20,
    textAlign:'left'
  },
});


export default App;