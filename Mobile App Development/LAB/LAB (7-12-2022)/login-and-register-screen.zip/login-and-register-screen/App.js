import React, { useState } from 'react';
import {TouchableOpacity,Image, Button, View, Text,TextInput,StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

function SignIn({ navigation ,route}) {
  const [email,setEmail] = useState('Email');
  const [pass,setPassword] = useState('Password');
  return (
    <View style={{flex:1, backgroundColor:'lightgrey', alignContent:'center'}}>
      <Image style={styles.icon}
        source={require('./assets/firebase.png')}></Image>
      <TextInput
        style={styles.input}
        onChangeText={setEmail}
        value={route.params.email}
      />
      <TextInput
        style={styles.input}
        onChangeText={setPassword}
        value={route.params.password}
        placeholder="Password"
        secureTextEntry={true}
      />
      <TouchableOpacity style={styles.loginButton}
        onPress={() => {alert('You have successful login!');}}>
        <Text 
        style={{fontSize:16, fontWeight:'bold', color:'white',          alignSelf:'center', padding:10}}>
        Log in</Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => {navigation.navigate('Registration')}}>
        <Text style={{alignSelf:'center',fontSize:14}}>Dont have an account? <Text style={{fontWeight:'bold', color:'blue'}}>Sign-Up</Text></Text>
      </TouchableOpacity>

    </View>
  );
};

function SignUp({ navigation }) 
{
  const [username, setUsername] = useState("");
   const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [cpassword, setCpassword] = useState("");

  return (
    <View style={{flex:1, backgroundColor:'lightgrey', alignContent:'center'}}>
    <Image style={styles.icon}
        source={require('./assets/firebase.png')}></Image>
      <TextInput
        style={styles.input}
        onChangeText={setUsername}
        value={username}
        placeholder="Username"
      />
        <TextInput
        style={styles.input}
        onChangeText={setEmail}
        value={email}
        placeholder="Email"
      />
        <TextInput
        style={styles.input}
        onChangeText={setPassword}
        value={password}
        placeholder="Password"
      />
      <TextInput
        style={styles.input}
        onChangeText={setCpassword}
        value={cpassword}
        placeholder="Password"
      />
      <TouchableOpacity style={styles.loginButton}
        onPress={() => {navigation.navigate('Login',
                        {email:email,
                        password:password
                      })
        }}>
        <Text 
        style={{fontSize:16, fontWeight:'bold', color:'white',          alignSelf:'center', padding:10}}>
        Create Account</Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => {navigation.navigate('Login')}}>
        <Text style={{alignSelf:'center',fontSize:14}}>Already got an account? <Text style={{fontWeight:'bold', color:'blue'}}>Log In</Text></Text>
      </TouchableOpacity>
    </View>
  );
};


  

const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Registration">
        <Stack.Screen name="Login" component={SignIn}/>
        <Stack.Screen name="Registration" component={SignUp}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  input: {
    height: 40,
    width:350,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    backgroundColor:'white',
    fontWeight:'bold',
    fontSize:17,
    alignSelf:'center'
  },
  loginButton:{
    alignSelf:'center',
    width:350,
    height:40,
    backgroundColor: 'darkblue',
    borderRadius:5,
    marginTop:20,
    marginBottom:10
  },
  icon:{
    marginTop:40,
    marginBottom:20,
    width:70,
    height:90,
    alignSelf:'center'
  },
});

export default App;