import React, { useState } from 'react';
import { Text, View, TouchableOpacity, StyleSheet, TextInput} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
const Stack = createNativeStackNavigator();

function CalculateGPA(){
  const [english, setEnglish]= useState(null);
  const [calculus, setCalculus]= useState(null);
  const [cp, setCp]= useState(null);
  const [Enggrade, setEngGrade] = useState('Your Grade');
  const [Calgrade, setCalGrade] = useState('Your Grade');
  const [Cpgrade, setCpGrade] = useState('Your Grade');
  const [result ,setResult]=useState(null);

  return(
    <View style={{flex:1}}>
    <Text style={styles.headingGpa}>Semester FALL 22</Text>
    <View style={styles.subjectNameBox}>
    <Text style={styles.subject}>  English</Text>
    </View>
    <View style={styles.marks}>
      <Text style={styles.subText}>
      {Enggrade}
      </Text>
      <TextInput 
        style={styles.subTextInput}
        onChangeText={English => {
          if(English <= 4.0){
            setEnglish(English);
            setEngGrade('A');
          }
          if(English <= 3.0){
            setEnglish(English);
            setEngGrade('B');
          }
          if(English <= 2.0){
            setEnglish(English);
            setEngGrade('C');
          }
          if(English <= 1.0){
            setEnglish(English);
            setEngGrade('F');
          }
        }}
        value={english}
        placeholder='Enter GPA'
      ></TextInput>
    </View>

    <View style={{height:20}}></View>

    <View style={styles.subjectNameBox}>
    <Text style={styles.subject}>  Calculus</Text>
    </View>
    <View style={styles.marks}>
      <Text style={styles.subText}>
      {Calgrade}
      </Text>
      <TextInput 
        style={styles.subTextInput}
        onChangeText={cal => {
          if(cal <= 4.0){
            setCalculus(cal);
            setCalGrade('A');
          }
          if(cal <= 3.0){
            setCalculus(cal);
            setCalGrade('B');
          }
          if(cal <= 2.0){
            setCalculus(cal);
            setCalGrade('C');
          }
          if(cal <= 1.0){
            setCalculus(cal);
            setCalGrade('F');
          }
        }}
        value={calculus}
        placeholder='Enter GPA'
      ></TextInput>
    </View>

    <View style={{height:20}}></View>

    <View style={styles.subjectNameBox}>
    <Text style={styles.subject}>  Computer Programming</Text>
    </View>
    <View style={styles.marks}>
      <Text style={styles.subText}>
      {Cpgrade}
      </Text>
      <TextInput 
        style={styles.subTextInput}
        onChangeText={comp => {
          if(comp <= 4.0){
            setCp(comp);
            setCpGrade('A');
          }
          if(comp <= 3.0){
            setCp(comp);
            setCpGrade('B');
          }
          if(comp <= 2.0){
            setCp(comp);
            setCpGrade('C');
          }
          if(comp <= 1.0){
            setCp(comp);
            setCpGrade('F');
          }
        }}
        value={cp}
        placeholder='Enter GPA'
      ></TextInput>
    </View>

    <TouchableOpacity style={styles.CalButton}>
      <Text style={styles.buttonText}
      onPress={()=>{
        var ans = ((english*3)+(calculus*3)+(cp*4))/10;
        ans = ans.toFixed(3);
        setResult(ans);
        }}
      >Calculate</Text>
    </TouchableOpacity>

    <View style={{width:390, borderWidth:1, borderColor: 'grey', marginTop:20, marginBottom:10, marginLeft: 10}}></View>
    <Text style={{fontSize:16, color:'grey', textAlign:'right', paddingRight:20, marginTop:20}}>Your GPA</Text>
    <Text style={styles.resultText}>{result}</Text>
  </View>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen 
          name = "GPA" 
          component = {CalculateGPA} 
          options={{ 
            title: 'GPA Calculator', 
            headerStyle: {
              backgroundColor: '#f08080',
            },
            headerTintColor: '#fff', 
          }}> </Stack.Screen>
      </Stack.Navigator>

    </NavigationContainer>

  );
}

const styles = StyleSheet.create({
  headingGpa:{
    color: '#f08080',
    fontWeight: 'bold',
    fontSize: 20,
    marginTop:10,
    marginLeft:25,
    marginBottom:20
  },
  subjectNameBox:{
    borderWidth:2,
    borderColor: 'black',
    width:300,
    height:30,
    marginTop:10,
    marginLeft:10,
    alignSelf:'center'
  },
  subject:{
    fontSize:16,
    fontWeight:'bold'
  },
  marks:{
    width:300,
    height:30,
    marginLeft:10,
    borderLeftWidth:2,
    borderEndWidth:2,
    borderBottomWidth:2,
    flexDirection:'row',
    alignSelf:'center'
  },
  subText:{
    borderLeftColor: 'grey',
    borderWidth:1,
    paddingLeft:3,
    width: 140,
    height:20,
    marginLeft:5,
    alignSelf:'center',
  },
  subTextInput:{
    borderLeftColor: 'grey',
    borderWidth:1,
    padding:3,
    width: 140,
    height:20,
    marginLeft:5,
    alignSelf:'center'
  },
  CalButton:{
    backgroundColor: '#f08080',
    height: 35,
    width:200,
    alignSelf:'center',
    marginTop:35,
    borderRadius:17,
    marginBottom:20
  },
  buttonText:{
    color: 'white',
    fontWeight: 'bold',
    fontSize: 18,
    alignSelf:'center',
    padding:5
  },
  resultText:{
    color: '#f08080',
    fontSize:20,
    fontWeight:'bold',
    textAlign:'right',
    paddingRight:20
  }
});